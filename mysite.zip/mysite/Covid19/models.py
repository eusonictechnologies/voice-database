from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.urls import reverse
from datetime import date


class Patient(models.Model):
    STATUS_CHOICES = {
        ('in_progress', 'In Progress'),
        ('tested', 'Tested'),
    }


    patient_name = models.CharField(max_length=250)
    slug = models.SlugField(max_length=250, unique_for_date='test_date')
    doctor = models.ForeignKey(User, related_name='blog_posts',
                               on_delete=models.DO_NOTHING)
    symptoms = models.TextField()

    test_date = models.DateTimeField(default=timezone.now)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    status = models.CharField(max_length=100,
                              choices=STATUS_CHOICES, default='tested')

    class Meta:
        ordering = ('-test_date',)

    def __str__(self):
        return self.patient_name

    def get_absolute_url(self):
        return reverse('blog:post_detail', args=[
            self.test_date.year,
            self.test_date.strftime('%m'),
            self.test_date.strftime('%d'),
            self.slug
        ])

    audiofile = models.FileField(upload_to='media/recordings/%Y/%m/%d', default="1", editable=False)

    def __unicode__(self):
        return self.decode(self.audiofile)

    def is_from_today(self):
        path_comp = self.audiofile._get_path().split('/')
        date_path = path_comp[-4:-1]  # Y/m/d
        date_comp = map(int, date_path)
        file_date = date(*date_comp)
        return file_date == date.today()
