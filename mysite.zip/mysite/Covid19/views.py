from django.shortcuts import render, get_object_or_404
from .models import Patient
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

from .forms import EmailPostForm
from django.core.mail import send_mail

from django.shortcuts import render
from django.template import RequestContext
from django.http import HttpResponseRedirect
from django.urls import reverse
from .models import Patient



# Create your views here.
def post_list(request):
    all_posts = Patient.objects.filter(status='published')
    my_paginator = Paginator(all_posts, 5)  # each page will contain 5 posts

    temp_page = request.GET.get('page')
    try:
        posts = my_paginator.page(temp_page)
    except PageNotAnInteger:
        posts = my_paginator.page(1)
    except EmptyPage:
        posts = my_paginator.page(my_paginator.num_pages)

    return render(request, 'post_list.html', {'posts': posts})


def post_detail(request, year, month, day, post):
    post = get_object_or_404(Patient, slug=post, status='published',
                             publish_date__year=year,
                             publish_date__month=month,
                             publish_date__day=day)

    return render(request, 'post_detail.html', {'post': post})


def post_share(request, post_id):
    post = get_object_or_404(Patient, id=post_id, status='published')
    sent = False

    if request.method == 'POST':
        form = EmailPostForm(request.POST)

        if form.is_valid():
            cd = form.cleaned_data
            post_url = request.build_absolute_uri(post.get_absolute_url())
            subject = f'{cd["name"]} ({cd["email"]}) sent you a blog post: "{post.title}"'
            message = f'Read "{post.title}" at {post_url}\n\n'
            message += f'Comments from {cd["name"]}: {cd["comments"]}'
            send_mail(subject, message, ' EMAIL ADDRESS GOES HERE', [cd['to']])
            sent = True
    else:
        form = EmailPostForm()

    return render(
        request,
        'post_share.html',
        {'post': post, 'form': form, 'sent': sent}
    )

def list_saved_files(request):
    # Handle file upload
    if request.method == 'POST':

        # https://docs.djangoproject.com/en/dev/ref/request-response
        #
        # request.POST: A dictionary-like object containing all given
        # HTTP POST parameters, providing that the request contains form data.
        # Note: POST does *not* include file-upload information.
        #
        # request.FILES: A dictionary-like object containing all uploaded files.
        # Each key in FILES is the name from the <input type="file" name="" />.
        # Each value in FILES is an UploadedFile.
        # Note: This only has data if the <form> that POSTed had enctype="multipart/form-data"
        form = EmailPostForm(request.POST, request.FILES)
        if form.is_valid():
            newrec = Patient(audiofile=request.FILES['audiofile'])
            newrec.save()

            # Redirect to the document list after POST
            return HttpResponseRedirect(reverse('Conversation.v1.views.list'))
    else:
        form = EmailPostForm()  # An empty, unbound form

    # Load documents for the list page
    recordings = Patient.objects.all()

    # Render list page with the documents and the form
    return render_to_response(
        'list.html',
        {'recordings': recordings, 'form': form},
        context_instance=RequestContext(request)
    )

def recorder_screen(request):
    if request.method == 'POST':
        newrec = Patient(audiofile=request.FILES['recording'])
        newrec.save()
        return HttpResponseRedirect(reverse('Conversation.v1.views.recorder_screen'))
    else:
        form = EmailPostForm()

    return render_to_response(
        'Audio Recorder.html',
        {'form' : form},
        context_instance=RequestContext(request)
    )