/**
 * alert.js
 * Ethan Petuchowski
 * 4/18/14
 */

console.log('helloz');
